import Foundation

/// Stores network activity logged from the WebView (JS-side fetch/XHR/resource hooks
/// plus native navigation decisions) to an in-memory array and a file in Documents,
/// so it survives app restarts and can be shared/exported.
final class NetworkLogger {

    static let shared = NetworkLogger()

    private let queue = DispatchQueue(label: "com.lockbrowser.networklogger")
    private let isoFormatter = ISO8601DateFormatter()

    private(set) var entries: [String] = []

    let fileURL: URL = {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("network_log.txt")
    }()

    private init() {
        // Load any existing log from disk on launch
        if let data = try? Data(contentsOf: fileURL),
           let text = String(data: data, encoding: .utf8) {
            entries = text.split(separator: "\n").map(String.init)
        }
    }

    /// Log a single request. Safe to call from any thread (including JS callbacks on main thread).
    func log(type: String, method: String, url: String, extra: String? = nil) {
        let timestamp = isoFormatter.string(from: Date())
        var line = "[\(timestamp)] \(type.uppercased()) \(method) \(url)"
        if let extra = extra, !extra.isEmpty {
            line += " (\(extra))"
        }

        queue.async {
            self.entries.append(line)
            self.appendToFile(line)
        }
        #if DEBUG
        print(line)
        #endif
    }

    private func appendToFile(_ line: String) {
        let data = (line + "\n").data(using: .utf8)!
        if FileManager.default.fileExists(atPath: fileURL.path) {
            if let handle = try? FileHandle(forWritingTo: fileURL) {
                handle.seekToEndOfFile()
                handle.write(data)
                try? handle.close()
            }
        } else {
            try? data.write(to: fileURL)
        }
    }

    func clear() {
        queue.async {
            self.entries.removeAll()
            try? FileManager.default.removeItem(at: self.fileURL)
        }
    }

    /// Returns a snapshot of the log as a single string (most recent last).
    func dumpText() -> String {
        queue.sync {
            entries.joined(separator: "\n")
        }
    }
}
