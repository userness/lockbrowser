import Foundation

/// JavaScript injected at document-start into every frame. Hooks the common
/// request-initiating APIs and forwards a record of each one to the native
/// side via `webkit.messageHandlers.networkLogger`.
///
/// Coverage:
///  - fetch()
///  - XMLHttpRequest (open)
///  - navigator.sendBeacon()
///  - All subresource loads via the Resource Timing API (images, scripts,
///    stylesheets, media, fonts, prefetch, etc.) — this is the broadest net
///    and catches requests the page didn't explicitly script.
///  - The document's own initial URL.
///
/// Note: this only sees requests initiated by page script/markup. Top-level
/// navigations and new-tab/popup attempts are logged separately, natively,
/// in WKNavigationDelegate / WKUIDelegate.
enum NetworkLoggerScript {
    static let source = """
    (function() {
        if (window.__lockbrowserLoggerInstalled) return;
        window.__lockbrowserLoggerInstalled = true;

        function send(type, method, url, initiator) {
            try {
                if (!url) return;
                window.webkit.messageHandlers.networkLogger.postMessage({
                    type: type,
                    method: method || 'GET',
                    url: String(url),
                    initiator: initiator || ''
                });
            } catch (e) { /* message handler not ready, ignore */ }
        }

        // --- fetch ---
        if (window.fetch) {
            const originalFetch = window.fetch;
            window.fetch = function(input, init) {
                try {
                    const url = (typeof input === 'string') ? input : (input && input.url);
                    const method = (init && init.method) || (input && input.method) || 'GET';
                    send('fetch', method, url);
                } catch (e) {}
                return originalFetch.apply(this, arguments);
            };
        }

        // --- XMLHttpRequest ---
        if (window.XMLHttpRequest) {
            const originalOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(method, url) {
                try { send('xhr', method, url); } catch (e) {}
                return originalOpen.apply(this, arguments);
            };
        }

        // --- sendBeacon ---
        if (navigator.sendBeacon) {
            const originalBeacon = navigator.sendBeacon.bind(navigator);
            navigator.sendBeacon = function(url, data) {
                try { send('beacon', 'POST', url); } catch (e) {}
                return originalBeacon(url, data);
            };
        }

        // --- All other subresource loads (images, scripts, css, media, fonts, etc.) ---
        try {
            const seen = new Set();
            const reportEntry = function(entry) {
                if (seen.has(entry.name)) return;
                seen.add(entry.name);
                send('resource', 'GET', entry.name, entry.initiatorType);
            };

            // Anything already loaded before the observer was attached
            if (window.performance && performance.getEntriesByType) {
                performance.getEntriesByType('resource').forEach(reportEntry);
            }

            if (window.PerformanceObserver) {
                const po = new PerformanceObserver(function(list) {
                    list.getEntries().forEach(reportEntry);
                });
                po.observe({ type: 'resource', buffered: true });
            }
        } catch (e) {}

        // --- The document itself ---
        send('document', 'GET', window.location.href);
    })();
    """
}
