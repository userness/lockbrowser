import UIKit
import WebKit

class BrowserViewController: UIViewController {

    // MARK: - Properties

    private var webView: WKWebView!
    private var progressBar: UIProgressView!
    private var urlBar: UITextField!
    private var toolbar: UIView!
    private var lockedHost: String? = nil
    private var progressObservation: NSKeyValueObservation?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupWebView()
        setupUI()
        setupObservers()
    }

    deinit {
        progressObservation?.invalidate()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "networkLogger")
    }

    // MARK: - Setup

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.preferences.javaScriptEnabled = true

        // Prevent window.open() and target="_blank" from opening new windows
        config.preferences.javaScriptCanOpenWindowsAutomatically = false

        // --- Network request logging ---
        // Injects a script that hooks fetch, XMLHttpRequest, sendBeacon, and the
        // Resource Timing API so essentially every request the page makes
        // (XHR/fetch + images/scripts/styles/media/etc.) gets reported back to us.
        let contentController = WKUserContentController()
        contentController.add(self, name: "networkLogger")
        contentController.addUserScript(
            WKUserScript(
                source: NetworkLoggerScript.source,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        config.userContentController = contentController

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.allowsBackForwardNavigationGestures = true
        view.addSubview(webView)
    }

    private func setupUI() {
        view.backgroundColor = UIColor(red: 0.08, green: 0.08, blue: 0.10, alpha: 1)

        // --- Top bar ---
        let topBar = UIView()
        topBar.translatesAutoresizingMaskIntoConstraints = false
        topBar.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.14, alpha: 1)
        view.addSubview(topBar)

        // Lock icon (left of URL bar)
        let lockIcon = UIImageView(image: UIImage(systemName: "lock.fill"))
        lockIcon.translatesAutoresizingMaskIntoConstraints = false
        lockIcon.tintColor = UIColor(red: 0.4, green: 0.9, blue: 0.6, alpha: 1)
        lockIcon.contentMode = .scaleAspectFit
        topBar.addSubview(lockIcon)

        // URL bar
        urlBar = UITextField()
        urlBar.translatesAutoresizingMaskIntoConstraints = false
        urlBar.backgroundColor = UIColor(red: 0.16, green: 0.16, blue: 0.20, alpha: 1)
        urlBar.textColor = .white
        urlBar.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        urlBar.attributedPlaceholder = NSAttributedString(
            string: "lockbrowser://open?url=https://...",
            attributes: [.foregroundColor: UIColor.gray]
        )
        urlBar.layer.cornerRadius = 8
        urlBar.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        urlBar.leftViewMode = .always
        urlBar.rightView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 1))
        urlBar.rightViewMode = .always
        urlBar.keyboardType = .URL
        urlBar.autocapitalizationType = .none
        urlBar.autocorrectionType = .no
        urlBar.returnKeyType = .go
        urlBar.delegate = self
        topBar.addSubview(urlBar)

        // Progress bar
        progressBar = UIProgressView(progressViewStyle: .bar)
        progressBar.translatesAutoresizingMaskIntoConstraints = false
        progressBar.progressTintColor = UIColor(red: 0.4, green: 0.9, blue: 0.6, alpha: 1)
        progressBar.trackTintColor = .clear
        progressBar.alpha = 0
        view.addSubview(progressBar)

        // --- Bottom toolbar ---
        toolbar = UIView()
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        toolbar.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.14, alpha: 1)
        view.addSubview(toolbar)

        let backBtn = makeToolbarButton(icon: "chevron.left", action: #selector(goBack))
        let fwdBtn = makeToolbarButton(icon: "chevron.right", action: #selector(goForward))
        let reloadBtn = makeToolbarButton(icon: "arrow.clockwise", action: #selector(reload))
        let logBtn = makeToolbarButton(icon: "list.bullet.rectangle", action: #selector(showLog))
        let unlockBtn = makeToolbarButton(icon: "lock.open", action: #selector(unlock))
        unlockBtn.tintColor = UIColor(red: 1.0, green: 0.5, blue: 0.3, alpha: 1)

        let stack = UIStackView(arrangedSubviews: [backBtn, fwdBtn, reloadBtn, logBtn, unlockBtn])
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        toolbar.addSubview(stack)

        // --- Constraints ---
        NSLayoutConstraint.activate([
            // Top bar
            topBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.heightAnchor.constraint(equalToConstant: 52),

            lockIcon.leadingAnchor.constraint(equalTo: topBar.leadingAnchor, constant: 12),
            lockIcon.centerYAnchor.constraint(equalTo: topBar.centerYAnchor),
            lockIcon.widthAnchor.constraint(equalToConstant: 16),
            lockIcon.heightAnchor.constraint(equalToConstant: 16),

            urlBar.leadingAnchor.constraint(equalTo: lockIcon.trailingAnchor, constant: 8),
            urlBar.trailingAnchor.constraint(equalTo: topBar.trailingAnchor, constant: -12),
            urlBar.centerYAnchor.constraint(equalTo: topBar.centerYAnchor),
            urlBar.heightAnchor.constraint(equalToConstant: 36),

            // Progress
            progressBar.topAnchor.constraint(equalTo: topBar.bottomAnchor),
            progressBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            progressBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            progressBar.heightAnchor.constraint(equalToConstant: 2),

            // WebView
            webView.topAnchor.constraint(equalTo: topBar.bottomAnchor, constant: 2),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: toolbar.topAnchor),

            // Bottom toolbar
            toolbar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: 50),

            stack.topAnchor.constraint(equalTo: toolbar.topAnchor),
            stack.bottomAnchor.constraint(equalTo: toolbar.bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: toolbar.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: toolbar.trailingAnchor),
        ])
    }

    private func makeToolbarButton(icon: String, action: Selector) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setImage(UIImage(systemName: icon), for: .normal)
        btn.tintColor = .white
        btn.addTarget(self, action: action, for: .touchUpInside)
        return btn
    }

    private func setupObservers() {
        progressObservation = webView.observe(\.estimatedProgress, options: .new) { [weak self] _, _ in
            guard let self = self else { return }
            let p = Float(self.webView.estimatedProgress)
            self.progressBar.setProgress(p, animated: true)
            UIView.animate(withDuration: 0.3) {
                self.progressBar.alpha = p < 1.0 ? 1 : 0
            }
            if p >= 1.0 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                    self.progressBar.setProgress(0, animated: false)
                }
            }
        }
    }

    // MARK: - Navigation

    func load(url: URL) {
        // Lock to this host on first load
        if lockedHost == nil {
            lockedHost = url.host
        }
        urlBar.text = url.absoluteString
        webView.load(URLRequest(url: url))
    }

    @objc private func goBack()    { webView.goBack() }
    @objc private func goForward() { webView.goForward() }
    @objc private func reload()    { webView.reload() }

    @objc private func showLog() {
        let logVC = LogViewerViewController()
        let nav = UINavigationController(rootViewController: logVC)
        nav.modalPresentationStyle = .pageSheet
        present(nav, animated: true)
    }

    @objc private func unlock() {
        let alert = UIAlertController(
            title: "Unlock Domain",
            message: "Remove the domain lock? The browser will allow navigation anywhere until a new URL is locked.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Unlock", style: .destructive) { [weak self] _ in
            self?.lockedHost = nil
            self?.showBanner("Domain lock removed")
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func showBanner(_ message: String) {
        let banner = UILabel()
        banner.text = message
        banner.textColor = .white
        banner.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        banner.backgroundColor = UIColor(red: 0.4, green: 0.9, blue: 0.6, alpha: 0.9)
        banner.textAlignment = .center
        banner.layer.cornerRadius = 8
        banner.clipsToBounds = true
        banner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(banner)

        NSLayoutConstraint.activate([
            banner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            banner.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -60),
            banner.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.8),
            banner.heightAnchor.constraint(equalToConstant: 36)
        ])

        UIView.animate(withDuration: 0.3, delay: 1.5, options: [], animations: {
            banner.alpha = 0
        }) { _ in banner.removeFromSuperview() }
    }
}

// MARK: - WKNavigationDelegate

extension BrowserViewController: WKNavigationDelegate {

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }

        let method = navigationAction.request.httpMethod ?? "GET"

        // Allow about:blank
        if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
            return
        }

        // Block new tab / window attempts (target="_blank", window.open)
        if navigationAction.targetFrame == nil {
            NetworkLogger.shared.log(type: "nav", method: method, url: url.absoluteString, extra: "BLOCKED new tab")
            decisionHandler(.cancel)
            showBanner("🚫 New tab blocked")
            return
        }

        // If a domain is locked, block navigation to any other host
        if let locked = lockedHost, url.host != locked {
            NetworkLogger.shared.log(type: "nav", method: method, url: url.absoluteString, extra: "BLOCKED cross-domain")
            decisionHandler(.cancel)
            showBanner("🔒 Blocked: \(url.host ?? "unknown domain")")
            return
        }

        // On the very first real navigation, lock to this host
        if lockedHost == nil, let host = url.host {
            lockedHost = host
            showBanner("🔒 Locked to \(host)")
        }

        NetworkLogger.shared.log(type: "nav", method: method, url: url.absoluteString)
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        urlBar.text = webView.url?.absoluteString
    }

    func webView(_ webView: WKWebView,
                 didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        showBanner("Failed to load page")
    }
}

// MARK: - WKUIDelegate (block all popups)

extension BrowserViewController: WKUIDelegate {

    // Returning nil blocks window.open()
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        let url = navigationAction.request.url?.absoluteString ?? "unknown"
        NetworkLogger.shared.log(type: "popup", method: "GET", url: url, extra: "BLOCKED window.open")
        showBanner("🚫 Popup blocked")
        return nil
    }

    func webViewDidClose(_ webView: WKWebView) {}
}

// MARK: - UITextFieldDelegate (URL bar)

extension BrowserViewController: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        guard var text = textField.text?.trimmingCharacters(in: .whitespaces), !text.isEmpty else {
            return true
        }
        if !text.hasPrefix("http://") && !text.hasPrefix("https://") {
            text = "https://" + text
        }
        if let url = URL(string: text) {
            load(url: url)
        }
        return true
    }
}

// MARK: - WKScriptMessageHandler (receives logged network requests from JS)

extension BrowserViewController: WKScriptMessageHandler {

    func userContentController(_ userContentController: WKUserContentController,
                                didReceive message: WKScriptMessage) {
        guard message.name == "networkLogger",
              let dict = message.body as? [String: Any],
              let type = dict["type"] as? String,
              let url = dict["url"] as? String else {
            return
        }
        let method = dict["method"] as? String ?? "GET"
        let extra = dict["initiator"] as? String
        NetworkLogger.shared.log(type: type, method: method, url: url, extra: extra)
    }
}

