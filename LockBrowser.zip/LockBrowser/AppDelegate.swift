import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        let vc = BrowserViewController()
        window?.rootViewController = vc
        window?.makeKeyAndVisible()
        return true
    }

    // Handle lockbrowser://open?url=https://example.com deep links
    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        guard url.scheme == "lockbrowser",
              url.host == "open",
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let targetParam = components.queryItems?.first(where: { $0.name == "url" })?.value,
              let targetURL = URL(string: targetParam) else {
            return false
        }

        if let vc = window?.rootViewController as? BrowserViewController {
            vc.load(url: targetURL)
        }
        return true
    }
}
