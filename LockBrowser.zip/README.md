# LockBrowser

A minimal iOS browser that locks navigation to a single domain. No new tabs, no redirects to other domains, no popups. Open via deep link: `lockbrowser://open?url=https://example.com`

---

## Features

- 🔒 Locks to the first domain you navigate to
- 🚫 Blocks `target="_blank"`, `window.open()`, and cross-domain redirects
- 🔗 Deep link: `lockbrowser://open?url=https://example.com`
- 🔓 Unlock button to release the domain lock manually
- 📋 **Network log** — records every request the page makes (fetch, XHR, images,
  scripts, beacons, navigations, and blocked attempts), viewable and shareable
  from the toolbar
- Dark UI with a monospace URL bar and progress indicator

---

## Repo layout (this is the whole point — only 2 things in your repo!)

```
your-repo/
├── .github/
│   └── workflows/
│       └── build.yml      ← from this project, place here
└── LockBrowser.zip          ← the project zip, committed AS-IS (do not unzip!)
```

The workflow unzips `LockBrowser.zip` itself during the build. To update the
app, just replace `LockBrowser.zip` with a new version and push — no need to
extract anything into your repo.

---

## Build & Install from iPhone (ESign workflow)

### Step 1 — Create the repo on your iPhone
1. Install **Working Copy** (Git client) from the App Store, or create the repo on github.com directly
2. Create a new repo, e.g. `LockBrowser`
3. Add `.github/workflows/build.yml` (from this download) at that exact path
4. Add `LockBrowser.zip` (from this download) to the **repo root** — do not unzip it
5. Commit and push to GitHub

---

### Step 2 — Trigger the build

Push triggers it automatically, or go to your repo on GitHub → Actions →
"Build LockBrowser IPA (ESign / unsigned)" → Run workflow.

The build takes ~5 minutes. When done, download `LockBrowser.ipa` from the
Artifacts section of that workflow run.

---

### Step 3 — Install with ESign

1. Download the `.ipa` from GitHub Actions to your iPhone (Safari → Files)
2. Open **ESign** → Library → Import → select the `.ipa`
3. Tap the app → Sign → pick one of ESign's certificates → Install
4. Trust the certificate in **Settings → VPN & Device Management** if prompted

> ESign's shared certificates get revoked by Apple periodically — if the app
> stops opening, just re-sign it in ESign again (no rebuild needed).

---

## Updating the app later

1. Make changes to the Swift source locally / re-download an updated zip from Claude
2. Replace `LockBrowser.zip` in the repo root with the new version (same filename)
3. Commit and push → Actions rebuilds → re-download IPA → re-sign in ESign

---

## Using the deep link

From anywhere on iOS (Safari, Shortcuts, Notes, another app):

```
lockbrowser://open?url=https://example.com
```

Tapping this opens LockBrowser and immediately navigates to `https://example.com`, locking to that domain.

**Shortcuts automation example:**
- Action: "Open URL" → `lockbrowser://open?url=https://your-internal-tool.com`
- Add to home screen as its own icon

---

## Viewing the network log

Tap the 📋 icon in the bottom toolbar to open the **Network Log** screen. It shows every request the page has made since the app was installed, one per line:

```
[2026-06-14T18:32:01Z] DOCUMENT GET https://example.com/
[2026-06-14T18:32:01Z] RESOURCE GET https://example.com/style.css (link)
[2026-06-14T18:32:02Z] FETCH POST https://api.example.com/track
[2026-06-14T18:32:03Z] NAV GET https://other-site.com (BLOCKED cross-domain)
```

- **Share icon** — exports the raw log file (`network_log.txt`) via the share sheet, so you can AirDrop/save/email it
- **Trash icon** — clears the log
- The log persists across app launches (stored in the app's Documents folder) until cleared

**What's captured:**
- Page navigations, including blocked cross-domain attempts and blocked new-tab/popup attempts (`nav` / `popup`, tagged `BLOCKED ...`)
- `fetch()` and `XMLHttpRequest` calls made by page JavaScript
- `navigator.sendBeacon()` calls
- Every subresource the page loads — images, scripts, stylesheets, fonts, media, etc. — via the Resource Timing API
- The top-level document URL itself

**Limitations:** this only sees activity inside the WebView (page-initiated requests). It won't capture traffic from native code, other apps, or anything happening below the WebKit layer (e.g. DNS, TLS handshakes, OS-level telemetry).

---

## Customising

| What | Where |
|---|---|
| Change bundle ID | `Info.plist` → `CFBundleIdentifier` + `project.pbxproj` → `PRODUCT_BUNDLE_IDENTIFIER` |
| Change URL scheme | `Info.plist` → `CFBundleURLSchemes` + `AppDelegate.swift` scheme check |
| Default start URL | `BrowserViewController.swift` → `viewDidLoad`, call `load(url:)` |
| Allow subdomains only | `BrowserViewController.swift` → `decidePolicyFor` — change `url.host != locked` to a suffix check |
| Adjust what's logged | `NetworkLoggerScript.swift` (JS-side hooks) and `BrowserViewController.swift` (native nav/popup logging) |
| Log format / storage location | `NetworkLogger.swift` |
